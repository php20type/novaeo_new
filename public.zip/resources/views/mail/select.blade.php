<h2>Hi, {{ $name }}</h2>
<p>Congratulation, You Are sortlisted for {{ $title}} We Will Inform You for Interview</p>

<p>Thank You</p>