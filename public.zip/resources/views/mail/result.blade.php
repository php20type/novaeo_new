<h2>Hi, {{ $name }}</h2>
<p>Congratulation, You Cracked Interview Successfully and You are selected for {{ $title}}</p>

<p>Thank You</p>