<h2>Hi, Novaeo</h2>

<p> <b>Name :</b> {{ $name}}</p>
<p> <b>Email :</b> {{ $email}}</p>
<p> <b>Mobile No :</b> {{ $mobile}}</p>
<p>{{ $messages}}</p>

<p>Thank You</p>