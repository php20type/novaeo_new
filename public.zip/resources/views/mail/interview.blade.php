<h2>Hi, {{ $name }}</h2>
<p>Your Interview Schedule at <b>{{ $interview_date}}</b></p>

<p>Thank You</p>