<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="login-sec-fix-main">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">
                <div class="left-login-img-fix">
                    <img src="<?php echo e(asset('assets/admin/img/home/sign-left-img.png')); ?>">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="right-login-sec-fix">
                    <h4>Sign Up</h4>
                    <form class="login-form-fix" method="post" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-2">
                            <label>Username *</label>
                            <input id="name" type="text" class="form-control position-relative <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group mb-2">

                            <label>Email *</label>
                            <input id="email" type="email" class="form-control position-relative <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group position-relative mb-2">
                            <label>Password *</label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                            <i class="fa-solid fa-eye login-icon-hide" onclick="showPassword(this)"></i>

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group position-relative mb-2">
                            <label>Re-Enter Password *</label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            <i class="fa-solid fa-eye login-icon-hide" onclick="showConfirmPassword(this)"></i>
                        </div>
                        <div class="form-group mb-2">
                            <button type="submit" class="login-btn" value="">Sign Up</button>
                        </div>
                        <div class="dont-account text-center">
                            <p>already have an account? <a href="<?php echo e(route('login')); ?>">Login!</a></p>
                        </div>
                        <div class="sign-up-sec">
                            <span>Sign Up with</span>
                            <a href="<?php echo e(route('candidate.google.login')); ?>" class="google-signup-btn btn btn-block"><img src="<?php echo e(asset('assets/admin/img/home/google.svg')); ?>"> &nbsp; Google</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function showPassword(obj) {
        var x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
        $(obj).toggleClass('fa-eye');
        $(obj).toggleClass('fa-eye-slash');

    }
    function showConfirmPassword(obj){
        var x = document.getElementById("password-confirm");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
        $(obj).toggleClass('fa-eye');
        $(obj).toggleClass('fa-eye-slash');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/auth/register.blade.php ENDPATH**/ ?>