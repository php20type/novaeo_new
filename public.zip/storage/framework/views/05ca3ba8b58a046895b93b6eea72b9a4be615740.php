<h1>Hi, <?php echo e($name); ?></h1>
<p>Your Interview Schedule at <b><?php echo e($interview_date); ?></b></p>

<p>Thank You</p><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/mail/interview.blade.php ENDPATH**/ ?>