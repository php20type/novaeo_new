<!-- Header Section Start -->
<header class="header-main-sec">
    <div class="container">
        <div class="header-main">
            <div class="header-logo-area">
                <div class="header-logo">
                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('assets/front/img/header-logo.png')); ?>" />
                    </a>
                </div>
                <div class="header-search-list">
                    <div class="header-menu-area">
                        <div class="header-menubar">
                            <a href="javascript:void(0)" class="menubar-btn">
                                <i class="fa-solid fa-bars"></i>
                            </a>
                            <nav class="header-nav">
                                <div class="menubar-close-btn">
                                    <a href="javascript:void(0)">
                                        <i class="fa-solid fa-xmark"></i>
                                    </a>
                                </div>
                                <ul>
                                    <li <?php if(request()->is('/')): ?> class="active" <?php endif; ?>>
                                        <a href="<?php echo e(route('home')); ?>">Home </a>
                                    </li>
                                    <!-- <li <?php if(request()->is('about-us')): ?> class="active" <?php endif; ?>>
                                        <a href="<?php echo e(route('about-us')); ?>">About Us </a>
                                    </li> -->
                                    <li <?php if(request()->is('our-team')): ?> class="active" <?php endif; ?>>
                                        <a href="<?php echo e(route('our-team')); ?>">Our Team</a>
                                    </li>
                                    <li <?php if(request()->is('visionary')): ?> class="active" <?php endif; ?>>
                                        <a href="<?php echo e(route('visionary')); ?>">The Visionary</a>
                                    </li>
                                    <li <?php if(request()->is('career')): ?> class="active" <?php endif; ?>>
                                        <a href="<?php echo e(route('career')); ?>">Careers</a>
                                    </li>
                                    <!-- <li <?php if(request()->is('apply-now')): ?> class="active" <?php endif; ?>>
                                        <a href="<?php echo e(route('apply-now')); ?>">Apply Now</a>
                                    </li> -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <?php if(empty(Auth::user())): ?>
                    <div class="header-btn">
                        <a href="<?php echo e(route('login')); ?>">Sign In</a>
                    </div>
                    <?php else: ?>
                    <?php
                    if(Auth::user()->profile!=NULL){
                        $profile=asset('uploads/profile').'/'.Auth::user()->profile;
                    }else{
                        $profile=asset('assets/front/img/default.png');

                    }
                    ?>
                    <div class="user-login-block ">
                        <div class="user-login-img">
                            <img src="<?php echo e($profile); ?>">
                        </div>
                        <div class="user-login-content-block">
                            <div class="user-login-content dropdown">
                                <a href="#" class="dropdown-toggle" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <h5><?php echo e(ucfirst(Auth::user()->name)); ?></h5>
                                    <p><?php echo e(Auth::user()->email); ?></p>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="<?php echo e(route('candidate-profile')); ?>"><i class="fa fa-user"></i> Manage Accounts</a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out"></i> Logout</a>
                                </div>

                            </div>
                            <div class="user-login-arrow">
                                <svg width="9" height="6" viewBox="0 0 9 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 1L4.39474 5L8 1" stroke="#868686" stroke-linecap="round"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
  
</header>
<!-- Header Section End --><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/include/header.blade.php ENDPATH**/ ?>