<h2>Hi, <?php echo e($name); ?></h2>
<p>Congratulation, You Are sortlisted for <?php echo e($title); ?> We Will Inform You for Interview</p>

<p>Thank You</p><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/mail/select.blade.php ENDPATH**/ ?>