
<?php $__env->startSection('content'); ?>
<!-- Person Section Start -->
<section class="profile-sec-main">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="profile-con-block">
                    <div class="profile-content">
                        <?php
                        if(Auth::user()->profile!=NULL){
                        $profile=asset('uploads/profile').'/'.Auth::user()->profile;
                        }else{
                        $profile=asset('assets/front/img/default.png');

                        }
                        ?>
                        <div class="profile-img-block">
                            <img src="<?php echo e($profile); ?>" />
                        </div>
                        <div class="profile-content-block">
                            <h4><?php echo e(Auth::user()->name); ?></h4>

                            <a href="javascript:void(0)"><?php echo e(Auth::user()->email); ?></a>
                            <div class="profile-skill-btn">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit Profile</a>
                                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#changePasswordModal">Change Password</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
                <?php elseif(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="job-con-block">
                    <h4>Job Applied</h4>
                    <div class="job-content-block">
                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="job-box-block">
                            <div class="job-detail-content">
                                <h5><?php echo e($application->job->title); ?></h5>
                            </div>
                            <?php if($application->status==0): ?>
                            <div class="job-detail-pending-btn">
                                <span> pending </span>
                            </div>
                            <?php endif; ?>
                            <?php if($application->status==1): ?>
                            <div class="job-detail-btn">
                                <span> Application Approved </span>
                            </div>
                            <?php endif; ?>
                            <?php if($application->status==2): ?>
                            <div class="job-detail-rejected-btn">
                                <span> Application Rejected </span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Person Section End -->

<!-- Modal -->
<div id="editProfileModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Profile</h2>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- <div class="col-md-6"> -->
                    <div class="popup-con-block">

                        <div class="popup-box">
                            <form method="post" enctype="multipart/form-data" action="<?php echo e(route('update-profile')); ?>">

                                <div class="row">
                                    <div class="col-md-12 form-field">
                                        <label>Name *</label>
                                        <input type="text" placeholder="" name="name" id="name" value="<?php echo e(Auth::user()->name); ?>" required />
                                    </div>
                                    <div class="col-md-12 form-field">
                                        <label>Upload Profile *</label>
                                        <input type="file" placeholder="" name="profile" id="profile" />
                                    </div>

                                </div>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-block btn-primary candidate-submit-btn">Submit</button>
                            </form>
                        </div>
                    </div>
                    <!-- </div> -->
                    <!-- <div class="col-md-6">
                        <div class="apply-img-block">
                            <img src="<?php echo e(asset('assets/front/img/apply-now-img.png')); ?>" />
                        </div>
                    </div> -->
                </div>
            </div>
        </div>

    </div>
</div>

<div id="changePasswordModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h2>Change Password</h2>
                <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- <div class="col-md-6"> -->
                    <div class="popup-con-block">

                        <div class="popup-box">
                            <form action="<?php echo e(route('update-password')); ?>" method="POST">

                                <div class="row">
                                    <div class="col-md-12 form-field">
                                        <label>Old Password *</label>
                                        <input type="password" placeholder="" name="old_password" id="old_password" placeholder="Old Password" required />
                                    </div>
                                    <div class="col-md-12 form-field">
                                        <label>New Password *</label>
                                        <input type="password" placeholder="" name="new_password" id="new_password" placeholder="New Password" required />
                                    </div>
                                    <div class="col-md-12 form-field">
                                        <label>Confirm New Password *</label>
                                        <input type="password" placeholder="" name="new_password_confirmation" id="new_password_confirmation" placeholder="Confirm New Password" required />
                                    </div>


                                </div>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-block btn-primary candidate-submit-btn">Submit</button>
                            </form>
                        </div>
                    </div>
                    <!-- </div> -->
                    <!-- <div class="col-md-6">
                        <div class="apply-img-block">
                            <img src="<?php echo e(asset('assets/front/img/apply-now-img.png')); ?>" />
                        </div>
                    </div> -->
                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/candidate-profile.blade.php ENDPATH**/ ?>