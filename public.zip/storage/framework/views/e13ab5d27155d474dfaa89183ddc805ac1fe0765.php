<h2>Hi, Novaeo</h2>

<p> <b>Name :</b> <?php echo e($name); ?></p>
<p> <b>Email :</b> <?php echo e($email); ?></p>
<p> <b>Mobile No :</b> <?php echo e($mobile); ?></p>
<p><?php echo e($messages); ?></p>

<p>Thank You</p><?php /**PATH C:\xampp\htdocs\novaeo\resources\views/mail/enquiry.blade.php ENDPATH**/ ?>